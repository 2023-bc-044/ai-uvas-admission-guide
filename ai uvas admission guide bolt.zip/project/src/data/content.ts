export interface Program {
  id: string;
  name: string;
  level: 'Undergraduate' | 'Graduate' | 'Postgraduate';
  duration: string;
  campus: string;
  eligibility: string;
  category: string;
}

export const programs: Program[] = [
  {
    id: 'dvm',
    name: 'Doctor of Veterinary Medicine (DVM)',
    level: 'Undergraduate',
    duration: '5 Years',
    campus: 'Main Campus / Pattoki',
    eligibility: 'F.Sc. (Pre-Medical) with minimum 50% marks + entry test',
    category: 'Veterinary',
  },
  {
    id: 'biotech',
    name: 'BS Biotechnology',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Medical) with minimum 50% marks + entry test',
    category: 'Life Sciences',
  },
  {
    id: 'fst',
    name: 'BS Food Science & Technology',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Medical / Pre-Engineering) with minimum 50% marks',
    category: 'Food Sciences',
  },
  {
    id: 'micro',
    name: 'BS Microbiology',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Medical) with minimum 50% marks + entry test',
    category: 'Life Sciences',
  },
  {
    id: 'biochem',
    name: 'BS Biochemistry',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Medical) with minimum 50% marks + entry test',
    category: 'Life Sciences',
  },
  {
    id: 'apchem',
    name: 'BS Applied Chemistry',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Engineering / Pre-Medical) with minimum 50% marks',
    category: 'Sciences',
  },
  {
    id: 'env',
    name: 'BS Environmental Sciences',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Medical / Pre-Engineering) with minimum 50% marks',
    category: 'Sciences',
  },
  {
    id: 'bm',
    name: 'BS Business Management',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'Intermediate (any discipline) with minimum 50% marks',
    category: 'Management',
  },
  {
    id: 'econ',
    name: 'BS Economics',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'Intermediate (any discipline) with minimum 45% marks',
    category: 'Management',
  },
  {
    id: 'it',
    name: 'BS Information Technology',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Main Campus',
    eligibility: 'F.Sc. (Pre-Engineering / ICS) with minimum 50% marks',
    category: 'Computing',
  },
  {
    id: 'poultry',
    name: 'BS Poultry Science',
    level: 'Undergraduate',
    duration: '4 Years',
    campus: 'Ravi Campus Pattoki',
    eligibility: 'F.Sc. (Pre-Medical) with minimum 50% marks + entry test',
    category: 'Veterinary',
  },
  {
    id: 'mphil-biochem',
    name: 'M.Phil Biochemistry',
    level: 'Graduate',
    duration: '2 Years',
    campus: 'Main Campus',
    eligibility: 'BS / M.Sc. in relevant field with minimum 2.5/4.0 CGPA + GAT',
    category: 'Life Sciences',
  },
  {
    id: 'phd-biochem',
    name: 'PhD Biochemistry',
    level: 'Postgraduate',
    duration: '3–5 Years',
    campus: 'Main Campus',
    eligibility: 'M.Phil / MS in relevant field with valid GAT-G subject test',
    category: 'Life Sciences',
  },
];

export interface FaqItem {
  q: string;
  a: string;
}

export const faqs: FaqItem[] = [
  {
    q: 'When do UVAS admissions usually open?',
    a: 'UVAS admissions typically open after the declaration of Intermediate results, around August each year. The online application window remains open for about two to three weeks.',
  },
  {
    q: 'How is merit calculated at UVAS?',
    a: 'Merit is generally calculated as 70% from Intermediate (or equivalent) marks and 30% from the entry test. The exact formula may vary by program and is confirmed in the yearly admission advertisement.',
  },
  {
    q: 'What is the duration of the DVM program?',
    a: 'The Doctor of Veterinary Medicine (DVM) is a 5-year professional degree program offered at the Main Campus and Pattoki Campus.',
  },
  {
    q: 'Is an entry test mandatory for all programs?',
    a: 'Yes, most undergraduate programs require an entry test. The test is conducted shortly after the application window closes, and merit lists are displayed within two weeks.',
  },
  {
    q: 'What are the eligibility requirements for BS programs?',
    a: 'Most BS programs require F.Sc. (Pre-Medical) with at least 50% marks, along with the entry test. A few management programs accept intermediate in any discipline.',
  },
  {
    q: 'Does UVAS offer scholarships?',
    a: 'Yes. UVAS offers need-based and merit-based scholarships, including PEEF, HEC Need-Based Scholarship, and various donor-funded scholarships. Students can apply after admission through the Financial Aid Office.',
  },
  {
    q: 'How much are the tuition fees?',
    a: 'As a public-sector university, UVAS fees are relatively affordable. Most undergraduate programs range from PKR 25,000 to PKR 60,000 per semester, with the DVM program on the higher side. Exact fees are announced in the prospectus each year.',
  },
  {
    q: 'Is there a quota or reservation policy?',
    a: 'Yes. Reservations apply as per Government of Punjab policy, including seats for Punjab domicile holders, women, minorities, and persons with disabilities. Specific quota percentages are announced in the admission advertisement.',
  },
];

export interface DocumentItem {
  id: string;
  label: string;
  hint?: string;
}

export const requiredDocuments: DocumentItem[] = [
  { id: 'matric', label: 'Attested copy of Matriculation Certificate' },
  { id: 'intermediate', label: 'Attested copy of Intermediate Certificate / Result Card' },
  { id: 'domicile', label: 'Domicile Certificate' },
  { id: 'character', label: 'Character Certificate from last institution attended' },
  { id: 'cnic', label: 'CNIC or B-Form (if under 18)' },
  { id: 'photos', label: 'Recent passport-size photographs (4 copies)' },
  { id: 'entrytest', label: 'Entry test result / admit card copy', hint: 'If applicable to your program' },
  { id: 'disability', label: 'Disability / Minority certificate', hint: 'If claiming relevant quota' },
];

export interface TimelineStep {
  step: number;
  title: string;
  description: string;
  icon: 'announce' | 'apply' | 'test' | 'merit' | 'fee' | 'enroll';
}

export const timeline: TimelineStep[] = [
  {
    step: 1,
    title: 'Admission Advertisement',
    description: 'UVAS announces admissions (usually around August). The advertisement lists programs, eligibility, schedule, and the prospectus link.',
    icon: 'announce',
  },
  {
    step: 2,
    title: 'Online Application',
    description: 'Fill out the online application on the admissions portal within the announced window (typically 2–3 weeks). Upload documents and pay the processing fee.',
    icon: 'apply',
  },
  {
    step: 3,
    title: 'Entry Test',
    description: 'Appear in the entry test conducted shortly after the application window closes. The test is mandatory for most undergraduate programs.',
    icon: 'test',
  },
  {
    step: 4,
    title: 'Merit List',
    description: 'Merit lists are displayed within two weeks of the test. Merit is generally 70% intermediate marks and 30% entry test. Check your name and program.',
    icon: 'merit',
  },
  {
    step: 5,
    title: 'Fee Submission',
    description: 'Selected candidates must deposit the first-semester fee and dues by the deadline given in the merit list to confirm their seat.',
    icon: 'fee',
  },
  {
    step: 6,
    title: 'Enrollment & Orientation',
    description: 'Submit original documents for verification, complete enrollment, and attend orientation to begin classes.',
    icon: 'enroll',
  },
];

export interface OfficialLink {
  label: string;
  url: string;
  description: string;
  icon: 'globe' | 'portal' | 'mail' | 'phone' | 'map' | 'help';
}

export const officialLinks: OfficialLink[] = [
  {
    label: 'UVAS Official Website',
    url: 'https://uvas.edu.pk',
    description: 'Main university website with news, departments, and announcements.',
    icon: 'globe',
  },
  {
    label: 'UVAS Admissions Portal',
    url: 'https://admissions.uvas.edu.pk',
    description: 'Apply online, check merit lists, and track your application status.',
    icon: 'portal',
  },
  {
    label: 'Contact Email',
    url: 'mailto:info@uvas.edu.pk',
    description: 'Email the university for general admission queries.',
    icon: 'mail',
  },
  {
    label: 'University Location',
    url: 'https://maps.google.com/?q=University+of+Veterinary+and+Animal+Sciences+Lahore',
    description: 'Syed Abdul Qadir Jillani (Cooper) Road, Lahore, Punjab.',
    icon: 'map',
  },
];

export const heroStats = [
  { label: 'Programs Offered', value: '30+' },
  { label: 'Years of Excellence', value: '120+' },
  { label: 'Campuses', value: '5' },
];

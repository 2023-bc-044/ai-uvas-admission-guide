import { useEffect, useState } from 'react';
import { GraduationCap, Menu, X } from 'lucide-react';
import { Link, navigate, useRoute } from '@/lib/router';

interface NavItem {
  to: string;
  label: string;
}

const NAV_ITEMS: NavItem[] = [
  { to: '/', label: 'Home' },
  { to: '/chat', label: 'Ask AI' },
  { to: '/faq', label: 'FAQ' },
  { to: '/programs', label: 'Programs' },
  { to: '/checklist', label: 'Checklist' },
  { to: '/timeline', label: 'Timeline' },
  { to: '/links', label: 'Links' },
];

export function Navbar() {
  const route = useRoute();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    setOpen(false);
  }, [route]);

  const isActive = (to: string) =>
    to === '/' ? route === '/' : route === to || route.startsWith(`${to}/`);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-white/90 backdrop-blur-md shadow-sm border-b border-stone-200/70'
          : 'bg-white/70 backdrop-blur-sm'
      }`}
    >
      <nav className="max-w-content mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-2.5 group"
            aria-label="UVAS Admission Guide home"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-700 text-white shadow-sm transition-transform group-hover:scale-105">
              <GraduationCap className="h-5 w-5" strokeWidth={2.2} />
            </span>
            <span className="flex flex-col leading-tight">
              <span className="font-display text-base font-semibold text-primary-800">
                UVAS Guide
              </span>
              <span className="text-[10px] uppercase tracking-[0.18em] text-stone-500">
                Admissions 2026
              </span>
            </span>
          </Link>

          {/* Desktop nav */}
          <ul className="hidden lg:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={`relative px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                    isActive(item.to)
                      ? 'text-primary-800'
                      : 'text-stone-600 hover:text-primary-700'
                  }`}
                >
                  {item.label}
                  {isActive(item.to) && (
                    <span className="absolute inset-x-3.5 -bottom-px h-0.5 rounded-full bg-primary-700" />
                  )}
                </Link>
              </li>
            ))}
          </ul>

          <div className="hidden lg:block">
            <button
              onClick={() => navigate('/chat')}
              className="inline-flex items-center gap-2 rounded-lg bg-primary-700 px-4 py-2 text-sm font-semibold text-white shadow-sm transition-all hover:bg-primary-800 hover:shadow-md active:scale-95"
            >
              Ask AI
            </button>
          </div>

          {/* Mobile toggle */}
          <button
            className="lg:hidden inline-flex h-10 w-10 items-center justify-center rounded-lg text-primary-800 hover:bg-primary-50 transition-colors"
            onClick={() => setOpen((v) => !v)}
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
          >
            {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile drawer */}
      <div
        className={`lg:hidden overflow-hidden transition-[max-height,opacity] duration-300 ease-out ${
          open ? 'max-h-[28rem] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <div className="bg-white border-t border-stone-200 px-4 py-4 space-y-1">
          {NAV_ITEMS.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`block rounded-lg px-4 py-2.5 text-sm font-medium transition-colors ${
                isActive(item.to)
                  ? 'bg-primary-50 text-primary-800'
                  : 'text-stone-700 hover:bg-stone-100'
              }`}
            >
              {item.label}
            </Link>
          ))}
          <button
            onClick={() => navigate('/chat')}
            className="mt-2 w-full rounded-lg bg-primary-700 px-4 py-2.5 text-sm font-semibold text-white shadow-sm"
          >
            Ask AI Assistant
          </button>
        </div>
      </div>
    </header>
  );
}

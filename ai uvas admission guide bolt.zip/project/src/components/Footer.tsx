import { GraduationCap, Mail, MapPin } from 'lucide-react';
import { Link } from '@/lib/router';

const FOOTER_LINKS = [
  { to: '/chat', label: 'Ask AI' },
  { to: '/faq', label: 'FAQ' },
  { to: '/programs', label: 'Program Finder' },
  { to: '/checklist', label: 'Document Checklist' },
  { to: '/timeline', label: 'Admission Timeline' },
  { to: '/links', label: 'Official Links' },
];

export function Footer() {
  return (
    <footer className="bg-primary-900 text-primary-50">
      <div className="max-w-content mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <div className="flex items-center gap-2.5">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/10">
                <GraduationCap className="h-5 w-5" />
              </span>
              <div className="leading-tight">
                <p className="font-display text-base font-semibold">AI UVAS Admission Guide</p>
                <p className="text-xs text-primary-200">University of Veterinary & Animal Sciences</p>
              </div>
            </div>
            <p className="mt-4 text-sm text-primary-200/90 max-w-sm">
              An unofficial assistant to help prospective students navigate UVAS
              admissions. Always verify details on the official UVAS website.
            </p>
          </div>

          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-primary-300">Explore</p>
            <ul className="mt-4 space-y-2.5">
              {FOOTER_LINKS.map((l) => (
                <li key={l.to}>
                  <Link
                    to={l.to}
                    className="text-sm text-primary-100 hover:text-white transition-colors"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <p className="text-xs uppercase tracking-[0.18em] text-primary-300">Official Contact</p>
            <ul className="mt-4 space-y-3 text-sm">
              <li className="flex items-start gap-2.5">
                <MapPin className="h-4 w-4 mt-0.5 text-primary-300 shrink-0" />
                <span className="text-primary-100">
                  Syed Abdul Qadir Jillani (Cooper) Road, Lahore
                </span>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 text-primary-300 shrink-0" />
                <a
                  href="mailto:info@uvas.edu.pk"
                  className="text-primary-100 hover:text-white transition-colors"
                >
                  info@uvas.edu.pk
                </a>
              </li>
            </ul>
            <a
              href="https://uvas.edu.pk"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-5 inline-flex items-center gap-2 rounded-lg bg-white/10 px-4 py-2 text-sm font-medium text-white hover:bg-white/20 transition-colors"
            >
              Visit UVAS Website
            </a>
          </div>
        </div>

        <div className="mt-10 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-primary-300">
            © {new Date().getFullYear()} AI UVAS Admission Guide. For informational purposes only.
          </p>
          <p className="text-xs text-primary-300">
            Not affiliated with UVAS. Verify at uvas.edu.pk
          </p>
        </div>
      </div>
    </footer>
  );
}

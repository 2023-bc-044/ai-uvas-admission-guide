// Retrieval-only chat engine for the UVAS Admission Guide.
// Grounds every answer exclusively in uvas_admission_data.txt (fetched at runtime).
// Never fabricates. Off-topic queries are politely redirected.
// Missing information triggers the official fallback message.

export const SYSTEM_PROMPT =
  "You are an AI assistant for UVAS admissions. Only use the provided UVAS admission information to answer questions. Be clear and concise. If the answer is not in the provided data, say: \"I'm sorry, I don't have that information. Please visit the official UVAS website.\" Never guess or answer unrelated questions.";

export const MISSING_INFO_REPLY =
  "I'm sorry, I don't have that information. Please visit the official UVAS website.";

export const OFF_TOPIC_REPLY =
  "I can only help with UVAS admission questions. Feel free to ask about programs, eligibility, fees, scholarships, the admission timeline, or required documents.";

const DATA_URL = `${import.meta.env.BASE_URL}uvas_admission_data.txt`;

let cachedData: string | null = null;

export async function loadAdmissionData(): Promise<string> {
  if (cachedData) return cachedData;
  const res = await fetch(DATA_URL, { cache: 'no-store' });
  if (!res.ok) throw new Error(`Failed to load admission data (${res.status})`);
  cachedData = (await res.text()).trim();
  return cachedData;
}

interface Passage {
  text: string;
  tokens: string[];
}

const STOP_WORDS = new Set([
  'the', 'a', 'an', 'and', 'or', 'of', 'to', 'in', 'for', 'on', 'is', 'are',
  'was', 'were', 'be', 'been', 'being', 'i', 'you', 'your', 'my', 'we', 'our',
  'what', 'when', 'where', 'how', 'why', 'who', 'which', 'do', 'does', 'did',
  'can', 'could', 'will', 'would', 'should', 'may', 'might', 'this', 'that',
  'these', 'those', 'it', 'its', 'about', 'into', 'with', 'as', 'at', 'by',
  'from', 'me', 'please', 'tell', 'give', 'know', 'want', 'need', 'help',
  'have', 'has', 'had', 'if', 'so', 'but', 'not', 'no', 'yes', 'there', 'their',
]);

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 1 && !STOP_WORDS.has(t));
}

function buildPassages(raw: string): Passage[] {
  // Split into section-style passages. Lines of ALL CAPS or dashes act as
  // section boundaries; otherwise group consecutive non-empty lines.
  const lines = raw.split(/\r?\n/);
  const passages: string[] = [];
  let buffer: string[] = [];

  const flush = () => {
    const block = buffer.join(' ').replace(/\s+/g, ' ').trim();
    if (block.length > 0) passages.push(block);
    buffer = [];
  };

  for (const line of lines) {
    const trimmed = line.trim();
    if (trimmed.length === 0) {
      flush();
      continue;
    }
    const isBoundary =
      /^[=\-_]{3,}$/.test(trimmed) || /^[A-Z][A-Z0-9 .&/\-]+$/.test(trimmed);
    if (isBoundary) {
      flush();
      buffer.push(trimmed.replace(/[=\-_]/g, '').trim());
    } else {
      buffer.push(trimmed);
    }
  }
  flush();

  return passages.map((text) => ({ text, tokens: tokenize(text) }));
}

const UVAS_TOPIC_TERMS = new Set([
  'uvas', 'university', 'veterinary', 'animal', 'sciences', 'admission',
  'admissions', 'admit', 'apply', 'application', 'program', 'programme',
  'programs', 'programmes', 'course', 'courses', 'dvm', 'bs', 'b.s', 'ms',
  'mphil', 'm.phil', 'phd', 'ph.d', 'degree', 'fee', 'fees', 'tuition',
  'scholarship', 'scholarships', 'financial', 'aid', 'eligibility',
  'eligible', 'entry', 'test', 'merit', 'criteria', 'requirement',
  'requirements', 'document', 'documents', 'checklist', 'deadline',
  'schedule', 'timeline', 'date', 'dates', 'quota', 'reservation',
  'domicile', 'campus', 'campuses', 'lahore', 'pattoki', 'enroll',
  'enrollment', 'registration', 'register', 'prospectus', 'result',
  'result card', 'intermediate', 'matric', 'fsc', 'pre', 'medical',
  'engineering', 'semester', 'cgpa', 'marks', 'percentage', 'vet',
  'medicine', 'biotechnology', 'microbiology', 'biochemistry', 'food',
  'poultry', 'science', 'technology', 'graduate', 'undergraduate',
  'postgraduate', 'pharmacy', 'nurse', 'hostel', 'transport',
]);

function isOnTopic(query: string): boolean {
  const tokens = tokenize(query);
  if (tokens.length === 0) return false;
  let hits = 0;
  for (const t of tokens) {
    if (UVAS_TOPIC_TERMS.has(t)) hits += 1;
  }
  // Also detect multi-word topic tokens.
  const lower = ` ${query.toLowerCase()} `;
  if (lower.includes('entry test') || lower.includes('merit list') ||
      lower.includes('fee structure') || lower.includes('how to apply') ||
      lower.includes('admission')) hits += 1;
  return hits >= 1;
}

function isGreeting(query: string): boolean {
  const lower = query.toLowerCase().trim();
  return /^(hi|hello|hey|salam|assalam|aoa|assalamualaikum|salaam|good (morning|afternoon|evening)|greetings)\b/.test(lower);
}

function scorePassage(queryTokens: string[], passage: Passage): number {
  const qSet = new Set(queryTokens);
  if (qSet.size === 0 || passage.tokens.length === 0) return 0;
  const pSet = new Set(passage.tokens);
  let score = 0;
  for (const t of qSet) {
    if (pSet.has(t)) {
      // Rare terms (longer) are more informative.
      score += t.length > 5 ? 2.2 : 1;
    } else if (passage.text.toLowerCase().includes(t)) {
      score += 0.4;
    }
  }
  // Coverage: fraction of query tokens present.
  const coverage = score / (qSet.size * 2.2);
  return score * (0.6 + coverage);
}

export interface ChatResult {
  reply: string;
  sources: string[];
  grounded: boolean;
}

export function answerQuery(query: string, data: string): ChatResult {
  const trimmed = query.trim();
  if (!trimmed) {
    return { reply: 'Please type a question about UVAS admissions.', sources: [], grounded: false };
  }

  if (isGreeting(trimmed)) {
    return {
      reply:
        "Hello! I'm the UVAS Admission Guide assistant. Ask me anything about UVAS admissions — programs, eligibility, fees, scholarships, the timeline, or required documents.",
      sources: [],
      grounded: false,
    };
  }

  if (!isOnTopic(trimmed)) {
    return { reply: OFF_TOPIC_REPLY, sources: [], grounded: false };
  }

  const passages = buildPassages(data);
  const queryTokens = tokenize(trimmed);
  const scored = passages
    .map((p) => ({ p, s: scorePassage(queryTokens, p) }))
    .sort((a, b) => b.s - a.s);

  const best = scored[0];
  // Threshold: need at least one strong token match to consider it grounded.
  if (!best || best.s < 1.6) {
    return { reply: MISSING_INFO_REPLY, sources: [], grounded: false };
  }

  // Gather supporting passages whose score is close to the best.
  const top = scored.filter((x) => x.s >= best.s * 0.55 && x.s >= 1.6).slice(0, 3);

  const replyParts = top.map((x) => x.p.text.replace(/\s+/g, ' ').trim());
  const sources = top.map((x) => {
    const firstLine = x.p.text.split(/\n|\.|:|;/)[0].trim();
    return firstLine.length > 0 ? firstLine.slice(0, 80) : 'UVAS admission data';
  });

  return {
    reply: replyParts.join('\n\n'),
    sources,
    grounded: true,
  };
}

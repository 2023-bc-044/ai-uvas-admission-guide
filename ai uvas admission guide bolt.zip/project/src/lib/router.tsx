import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';

type RouteListener = (path: string) => void;

const listeners = new Set<RouteListener>();

function getHashPath(): string {
  const hash = window.location.hash.replace(/^#/, '');
  return hash.startsWith('/') ? hash : `/${hash}`;
}

function notify() {
  const path = getHashPath();
  listeners.forEach((l) => l(path));
}

export function navigate(to: string) {
  if (!to.startsWith('/')) to = `/${to}`;
  if (getHashPath() === to) return;
  window.location.hash = to;
}

export function useRoute(): string {
  const [path, setPath] = useState<string>(getHashPath());
  useEffect(() => {
    const listener: RouteListener = (p) => setPath(p);
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  }, []);
  useEffect(() => {
    const onHash = () => notify();
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  return path;
}

interface LinkProps {
  to: string;
  children: ReactNode;
  className?: string;
  onClick?: () => void;
  'aria-label'?: string;
}

export function Link({ to, children, className, onClick, ...rest }: LinkProps) {
  return (
    <a
      href={`#${to}`}
      className={className}
      onClick={(e) => {
        e.preventDefault();
        navigate(to);
        onClick?.();
      }}
      {...rest}
    >
      {children}
    </a>
  );
}

export const RouteContext = createContext<string>('/');
export const useRouteContext = () => useContext(RouteContext);

export function scrollOrNotifyOnNavigate(to: string) {
  navigate(to);
}

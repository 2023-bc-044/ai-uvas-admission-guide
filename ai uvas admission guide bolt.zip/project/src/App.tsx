import { useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { useRoute } from '@/lib/router';
import { HomePage } from '@/pages/HomePage';
import { ChatbotPage } from '@/pages/ChatbotPage';
import { FaqPage } from '@/pages/FaqPage';
import { ProgramsPage } from '@/pages/ProgramsPage';
import { ChecklistPage } from '@/pages/ChecklistPage';
import { TimelinePage } from '@/pages/TimelinePage';
import { LinksPage } from '@/pages/LinksPage';
import { Link2 } from 'lucide-react';
import { Link, navigate } from '@/lib/router';

function NotFound() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20 flex items-center">
      <div className="max-w-md mx-auto px-6 text-center">
        <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-primary-50 text-primary-700">
          <Link2 className="h-7 w-7" />
        </span>
        <h1 className="mt-6 font-display text-3xl font-semibold text-stone-900">Page not found</h1>
        <p className="mt-3 text-stone-600">
          The page you're looking for doesn't exist. Let's get you back on track.
        </p>
        <button
          onClick={() => navigate('/')}
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary-700 px-5 py-3 text-sm font-semibold text-white transition-all hover:bg-primary-800 active:scale-95"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
}

function App() {
  const route = useRoute();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'auto' });
  }, [route]);

  const renderPage = () => {
    switch (route) {
      case '/':
        return <HomePage />;
      case '/chat':
        return <ChatbotPage />;
      case '/faq':
        return <FaqPage />;
      case '/programs':
        return <ProgramsPage />;
      case '/checklist':
        return <ChecklistPage />;
      case '/timeline':
        return <TimelinePage />;
      case '/links':
        return <LinksPage />;
      default:
        return <NotFound />;
    }
  };

  return (
    <div className="flex min-h-screen flex-col">
      <Navbar />
      <main className="flex-1">{renderPage()}</main>
      <Footer />
    </div>
  );
}

export default App;

import { useEffect, useState } from 'react';
import { CheckCircle2, Circle, FileCheck2, RotateCcw } from 'lucide-react';
import { requiredDocuments } from '@/data/content';
import { Reveal } from '@/components/Reveal';

const STORAGE_KEY = 'uvas-doc-checklist';

export function ChecklistPage() {
  const [checked, setChecked] = useState<Record<string, boolean>>({});

  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setChecked(JSON.parse(raw));
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(checked));
    } catch {
      /* ignore */
    }
  }, [checked]);

  const toggle = (id: string) =>
    setChecked((c) => ({ ...c, [id]: !c[id] }));

  const reset = () => setChecked({});

  const doneCount = requiredDocuments.filter((d) => checked[d.id]).length;
  const progress = Math.round((doneCount / requiredDocuments.length) * 100);
  const allDone = doneCount === requiredDocuments.length;

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Reveal className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-3.5 py-1.5 text-xs font-medium text-primary-700">
            <FileCheck2 className="h-3.5 w-3.5" />
            Document Checklist
          </span>
          <h1 className="mt-5 font-display text-3xl sm:text-4xl font-semibold text-stone-900 text-balance">
            Don't miss a single document
          </h1>
          <p className="mt-4 text-stone-600">
            Tick off each document as you prepare it. Your progress is saved on
            this device.
          </p>
        </Reveal>

        {/* Progress */}
        <Reveal delay={80}>
          <div className="mt-8 rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-stone-700">
                  {doneCount} of {requiredDocuments.length} documents ready
                </p>
                <p className="text-xs text-stone-400">
                  {allDone ? "You're all set to apply!" : 'Keep going — almost there.'}
                </p>
              </div>
              <button
                onClick={reset}
                className="inline-flex items-center gap-1.5 rounded-lg bg-stone-100 px-3 py-1.5 text-xs font-medium text-stone-600 transition-colors hover:bg-stone-200"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                Reset
              </button>
            </div>
            <div className="mt-4 h-2.5 w-full overflow-hidden rounded-full bg-stone-100">
              <div
                className="h-full rounded-full bg-gradient-to-r from-primary-500 to-primary-700 transition-all duration-500 ease-out"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </Reveal>

        {/* List */}
        <div className="mt-6 space-y-2.5">
          {requiredDocuments.map((d, i) => {
            const isChecked = !!checked[d.id];
            return (
              <Reveal key={d.id} delay={i * 40}>
                <button
                  onClick={() => toggle(d.id)}
                  className={`group flex w-full items-center gap-4 rounded-2xl border bg-white p-4 text-left transition-all ${
                    isChecked
                      ? 'border-primary-200 bg-primary-50/40'
                      : 'border-stone-200 hover:border-primary-200 hover:bg-stone-50'
                  }`}
                  aria-pressed={isChecked}
                >
                  <span
                    className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-all ${
                      isChecked ? 'bg-primary-700 text-white' : 'bg-stone-100 text-stone-400 group-hover:text-stone-500'
                    }`}
                  >
                    {isChecked ? <CheckCircle2 className="h-5 w-5" /> : <Circle className="h-5 w-5" />}
                  </span>
                  <span className="flex-1">
                    <span
                      className={`block text-sm font-medium transition-colors ${
                        isChecked ? 'text-stone-500 line-through' : 'text-stone-800'
                      }`}
                    >
                      {d.label}
                    </span>
                    {d.hint && (
                      <span className="mt-0.5 block text-xs text-stone-400">{d.hint}</span>
                    )}
                  </span>
                </button>
              </Reveal>
            );
          })}
        </div>

        {allDone && (
          <Reveal>
            <div className="mt-8 rounded-2xl bg-gradient-to-br from-primary-700 to-primary-900 px-6 py-6 text-center text-white animate-scaleIn">
              <CheckCircle2 className="h-9 w-9 mx-auto text-accent-300" />
              <h2 className="mt-3 font-display text-xl font-semibold">All documents ready!</h2>
              <p className="mt-1.5 text-sm text-primary-100/90">
                Head to the official UVAS admissions portal to submit your application.
              </p>
            </div>
          </Reveal>
        )}
      </div>
    </div>
  );
}

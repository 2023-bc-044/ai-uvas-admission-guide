import { useMemo, useState } from 'react';
import { GraduationCap, MapPin, Search, Timer, X } from 'lucide-react';
import { programs, type Program } from '@/data/content';
import { Reveal } from '@/components/Reveal';

const LEVELS = ['All', 'Undergraduate', 'Graduate', 'Postgraduate'] as const;

const CATEGORIES = [
  'All',
  'Veterinary',
  'Life Sciences',
  'Food Sciences',
  'Sciences',
  'Management',
  'Computing',
] as const;

export function ProgramsPage() {
  const [query, setQuery] = useState('');
  const [level, setLevel] = useState<(typeof LEVELS)[number]>('All');
  const [category, setCategory] = useState<(typeof CATEGORIES)[number]>('All');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return programs.filter((p) => {
      const matchesQ =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.campus.toLowerCase().includes(q) ||
        p.eligibility.toLowerCase().includes(q) ||
        p.duration.toLowerCase().includes(q);
      const matchesLevel = level === 'All' || p.level === level;
      const matchesCat = category === 'All' || p.category === category;
      return matchesQ && matchesLevel && matchesCat;
    });
  }, [query, level, category]);

  const hasFilters = query || level !== 'All' || category !== 'All';

  const clear = () => {
    setQuery('');
    setLevel('All');
    setCategory('All');
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20">
      <div className="max-w-content mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Reveal className="text-center max-w-2xl mx-auto">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-3.5 py-1.5 text-xs font-medium text-primary-700">
            <GraduationCap className="h-3.5 w-3.5" />
            Program Finder
          </span>
          <h1 className="mt-5 font-display text-3xl sm:text-4xl font-semibold text-stone-900 text-balance">
            Find the right UVAS program for you
          </h1>
          <p className="mt-4 text-stone-600">
            Search and filter every program by name, level, category, campus,
            or eligibility.
          </p>
        </Reveal>

        {/* Controls */}
        <Reveal delay={80}>
          <div className="mt-10 rounded-2xl border border-stone-200 bg-white p-4 sm:p-5 shadow-sm">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-5 w-5 text-stone-400" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search programs, campuses, eligibility…"
                className="w-full rounded-xl bg-stone-50 py-3 pl-11 pr-10 text-sm text-stone-800 placeholder:text-stone-400 ring-1 ring-stone-200 focus:ring-2 focus:ring-primary-500 focus:outline-none transition"
              />
              {query && (
                <button
                  onClick={() => setQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 flex h-6 w-6 items-center justify-center rounded-full text-stone-400 hover:bg-stone-200 hover:text-stone-600"
                  aria-label="Clear search"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
            </div>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <div>
                <p className="text-xs font-medium text-stone-500 mb-2">Level</p>
                <div className="flex flex-wrap gap-1.5">
                  {LEVELS.map((l) => (
                    <Chip key={l} active={level === l} onClick={() => setLevel(l)}>
                      {l}
                    </Chip>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs font-medium text-stone-500 mb-2">Category</p>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORIES.map((c) => (
                    <Chip key={c} active={category === c} onClick={() => setCategory(c)}>
                      {c}
                    </Chip>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 flex items-center justify-between">
              <p className="text-sm text-stone-500">
                <span className="font-semibold text-stone-800">{filtered.length}</span> program
                {filtered.length === 1 ? '' : 's'} found
              </p>
              {hasFilters && (
                <button
                  onClick={clear}
                  className="inline-flex items-center gap-1 text-sm font-medium text-primary-700 hover:text-primary-800"
                >
                  <X className="h-3.5 w-3.5" />
                  Clear filters
                </button>
              )}
            </div>
          </div>
        </Reveal>

        {/* Results */}
        {filtered.length === 0 ? (
          <Reveal>
            <div className="mt-10 rounded-2xl border border-dashed border-stone-300 bg-white p-12 text-center">
              <p className="text-stone-500">No programs match your search. Try different filters.</p>
            </div>
          </Reveal>
        ) : (
          <>
            {/* Desktop table */}
          <div className="mt-8 hidden md:block overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-primary-50/60 text-left text-xs uppercase tracking-wider text-primary-800">
                  <th className="px-5 py-3.5 font-semibold">Program</th>
                  <th className="px-5 py-3.5 font-semibold">Level</th>
                  <th className="px-5 py-3.5 font-semibold">Duration</th>
                  <th className="px-5 py-3.5 font-semibold">Campus</th>
                  <th className="px-5 py-3.5 font-semibold">Eligibility</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-100">
                {filtered.map((p, i) => (
                  <tr
                    key={p.id}
                    className="transition-colors hover:bg-primary-50/30 animate-fadeInUp"
                    style={{ animationDelay: `${i * 30}ms` }}
                  >
                    <td className="px-5 py-4">
                      <div className="font-medium text-stone-900">{p.name}</div>
                      <div className="mt-0.5 text-xs text-stone-400">{p.category}</div>
                    </td>
                    <td className="px-5 py-4">
                      <LevelBadge level={p.level} />
                    </td>
                    <td className="px-5 py-4 text-stone-700">{p.duration}</td>
                    <td className="px-5 py-4 text-stone-700">{p.campus}</td>
                    <td className="px-5 py-4 text-stone-600">{p.eligibility}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="mt-8 grid gap-4 md:hidden">
            {filtered.map((p, i) => (
              <Reveal key={p.id} delay={i * 40}>
                <ProgramCard program={p} />
              </Reveal>
            ))}
          </div>
          </>
        )}
      </div>
    </div>
  );
}

function Chip({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      onClick={onClick}
      className={`rounded-full px-3 py-1.5 text-xs font-medium transition-all ${
        active
          ? 'bg-primary-700 text-white shadow-sm'
          : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
      }`}
    >
      {children}
    </button>
  );
}

function LevelBadge({ level }: { level: Program['level'] }) {
  const styles: Record<Program['level'], string> = {
    Undergraduate: 'bg-primary-50 text-primary-700',
    Graduate: 'bg-accent-50 text-accent-700',
    Postgraduate: 'bg-stone-200 text-stone-700',
  };
  return (
    <span className={`inline-flex items-center rounded-md px-2 py-0.5 text-xs font-medium ${styles[level]}`}>
      {level}
    </span>
  );
}

function ProgramCard({ program }: { program: Program }) {
  return (
    <div className="rounded-2xl border border-stone-200 bg-white p-5 shadow-sm">
      <div className="flex items-start justify-between gap-3">
        <h3 className="font-display text-base font-semibold text-stone-900">{program.name}</h3>
        <LevelBadge level={program.level} />
      </div>
      <p className="mt-1 text-xs text-stone-400">{program.category}</p>
      <dl className="mt-4 space-y-2.5 text-sm">
        <div className="flex items-center gap-2.5">
          <Timer className="h-4 w-4 text-primary-600 shrink-0" />
          <dt className="text-stone-500">Duration:</dt>
          <dd className="font-medium text-stone-800">{program.duration}</dd>
        </div>
        <div className="flex items-center gap-2.5">
          <MapPin className="h-4 w-4 text-primary-600 shrink-0" />
          <dt className="text-stone-500">Campus:</dt>
          <dd className="font-medium text-stone-800">{program.campus}</dd>
        </div>
        <div className="pt-1">
          <dt className="text-stone-500 text-xs uppercase tracking-wide">Eligibility</dt>
          <dd className="mt-1 text-stone-700">{program.eligibility}</dd>
        </div>
      </dl>
    </div>
  );
}

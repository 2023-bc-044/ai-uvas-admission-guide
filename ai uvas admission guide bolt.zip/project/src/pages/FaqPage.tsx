import { useState } from 'react';
import { ChevronDown, HelpCircle, MessageSquareText } from 'lucide-react';
import { faqs } from '@/data/content';
import { navigate } from '@/lib/router';
import { Reveal } from '@/components/Reveal';

export function FaqPage() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Reveal className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-3.5 py-1.5 text-xs font-medium text-primary-700">
            <HelpCircle className="h-3.5 w-3.5" />
            Frequently Asked Questions
          </span>
          <h1 className="mt-5 font-display text-3xl sm:text-4xl font-semibold text-stone-900 text-balance">
            Quick answers about UVAS admissions
          </h1>
          <p className="mt-4 text-stone-600">
            Common questions prospective students ask. Can't find your answer?
            Ask the AI assistant directly.
          </p>
        </Reveal>

        <div className="mt-10 space-y-3">
          {faqs.map((f, i) => {
            const isOpen = open === i;
            return (
              <Reveal key={i} delay={i * 50}>
                <div
                  className={`rounded-2xl border bg-white transition-all duration-300 ${
                    isOpen ? 'border-primary-200 shadow-md shadow-primary-900/5' : 'border-stone-200 hover:border-stone-300'
                  }`}
                >
                  <button
                    onClick={() => setOpen(isOpen ? null : i)}
                    className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                    aria-expanded={isOpen}
                  >
                    <span className="font-medium text-stone-900">{f.q}</span>
                    <span
                      className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full transition-all duration-300 ${
                        isOpen ? 'bg-primary-700 text-white rotate-180' : 'bg-stone-100 text-stone-500'
                      }`}
                    >
                      <ChevronDown className="h-4 w-4" />
                    </span>
                  </button>
                  <div
                    className={`grid transition-all duration-300 ease-out ${
                      isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'
                    }`}
                  >
                    <div className="overflow-hidden">
                      <p className="px-5 pb-5 text-sm leading-relaxed text-stone-600">{f.a}</p>
                    </div>
                  </div>
                </div>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-12 rounded-2xl bg-gradient-to-br from-primary-700 to-primary-900 px-6 py-8 text-center text-white">
            <MessageSquareText className="h-8 w-8 mx-auto text-accent-300" />
            <h2 className="mt-4 font-display text-xl font-semibold">Have a different question?</h2>
            <p className="mt-2 text-sm text-primary-100/90">
              The AI assistant can answer anything about UVAS admissions.
            </p>
            <button
              onClick={() => navigate('/chat')}
              className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-primary-800 transition-all hover:bg-accent-50 active:scale-95"
            >
              Ask the AI Assistant
            </button>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

import {
  Bot,
  CheckSquare,
  ChevronRight,
  Clock,
  FileText,
  GraduationCap,
  HelpCircle,
  Link2,
  MessageSquareText,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import { Link, navigate } from '@/lib/router';
import { Reveal } from '@/components/Reveal';
import { heroStats } from '@/data/content';

const FEATURES = [
  {
    to: '/chat',
    icon: MessageSquareText,
    title: 'Ask AI Assistant',
    desc: 'Get instant, accurate answers grounded only in official UVAS admission data — no guessing.',
  },
  {
    to: '/programs',
    icon: GraduationCap,
    title: 'Program Finder',
    desc: 'Search every program by duration, campus, and eligibility in one clean, filterable list.',
  },
  {
    to: '/checklist',
    icon: CheckSquare,
    title: 'Document Checklist',
    desc: 'A tickable list of every document you need to submit with your application.',
  },
  {
    to: '/timeline',
    icon: Clock,
    title: 'Admission Timeline',
    desc: 'A visual step-by-step guide from advertisement to enrollment.',
  },
  {
    to: '/faq',
    icon: HelpCircle,
    title: 'FAQ',
    desc: 'Quick answers to the most common questions about UVAS admissions.',
  },
  {
    to: '/links',
    icon: Link2,
    title: 'Official Links',
    desc: 'Direct links to the UVAS admissions portal and contact resources.',
  },
];

const TRUST = [
  { icon: ShieldCheck, label: 'Grounded in official data only' },
  { icon: Bot, label: 'AI refuses to make up answers' },
  { icon: Sparkles, label: 'Instant, clear responses' },
];

export function HomePage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary-800 via-primary-800 to-primary-900 text-white">
        <div className="absolute inset-0 opacity-[0.07] pointer-events-none">
          <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-accent-300 blur-3xl" />
          <div className="absolute top-1/3 -right-32 h-96 w-96 rounded-full bg-primary-300 blur-3xl" />
        </div>
        <div className="absolute inset-0 opacity-[0.04] pointer-events-none"
             style={{
               backgroundImage:
                 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)',
               backgroundSize: '28px 28px',
             }}
        />

        <div className="relative max-w-content mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-20 sm:pt-36 sm:pb-28">
          <div className="grid lg:grid-cols-[1.1fr_0.9fr] gap-12 items-center">
            <div>
              <Reveal>
                <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3.5 py-1.5 text-xs font-medium text-primary-100 ring-1 ring-white/15">
                  <Sparkles className="h-3.5 w-3.5 text-accent-300" />
                  Powered by grounded AI · Admissions 2026
                </span>
              </Reveal>
              <Reveal delay={80}>
                <h1 className="mt-6 font-display text-4xl sm:text-5xl lg:text-6xl font-semibold leading-[1.05] tracking-tight text-balance">
                  Your smart guide to{' '}
                  <span className="text-accent-300">UVAS Lahore</span> admissions
                </h1>
              </Reveal>
              <Reveal delay={160}>
                <p className="mt-6 max-w-xl text-lg text-primary-100/90 leading-relaxed">
                  Ask any question about UVAS admissions and get instant,
                  accurate answers drawn exclusively from official admission
                  information. No guesswork — just clear, verified guidance.
                </p>
              </Reveal>
              <Reveal delay={240}>
                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => navigate('/chat')}
                    className="group inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-base font-semibold text-primary-800 shadow-lg shadow-primary-950/20 transition-all hover:bg-accent-50 hover:shadow-xl active:scale-95"
                  >
                    <Bot className="h-5 w-5" />
                    Ask AI
                    <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                  </button>
                  <Link
                    to="/programs"
                    className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-6 py-3.5 text-base font-semibold text-white ring-1 ring-white/20 transition-all hover:bg-white/15"
                  >
                    Explore Programs
                  </Link>
                </div>
              </Reveal>
              <Reveal delay={320}>
                <ul className="mt-9 flex flex-wrap gap-x-6 gap-y-2.5">
                  {TRUST.map((t) => (
                    <li key={t.label} className="flex items-center gap-2 text-sm text-primary-100/90">
                      <t.icon className="h-4 w-4 text-accent-300" />
                      {t.label}
                    </li>
                  ))}
                </ul>
              </Reveal>
            </div>

            {/* Hero visual card */}
            <Reveal delay={200} className="hidden lg:block">
              <div className="relative">
                <div className="absolute -inset-4 rounded-3xl bg-gradient-to-br from-accent-300/20 to-primary-300/20 blur-2xl" />
                <div className="relative rounded-3xl bg-white/5 p-2 ring-1 ring-white/10 backdrop-blur-sm animate-float">
                  <div className="rounded-2xl bg-white p-5 shadow-2xl">
                    <div className="flex items-center gap-3 border-b border-stone-100 pb-3">
                      <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary-700 text-white">
                        <Bot className="h-5 w-5" />
                      </span>
                      <div>
                        <p className="text-sm font-semibold text-stone-800">UVAS Admission Assistant</p>
                        <p className="text-[11px] text-stone-400">Online · grounded in official data</p>
                      </div>
                    </div>
                    <div className="space-y-3 py-4">
                      <div className="ml-auto max-w-[80%] rounded-2xl rounded-tr-sm bg-primary-700 px-3.5 py-2.5 text-sm text-white">
                        What is the duration of the DVM program?
                      </div>
                      <div className="max-w-[88%] rounded-2xl rounded-tl-sm bg-stone-100 px-3.5 py-2.5 text-sm text-stone-700">
                        The Doctor of Veterinary Medicine (DVM) is a 5-year
                        professional degree program offered at the Main Campus
                        and Pattoki Campus.
                      </div>
                      <div className="ml-auto max-w-[80%] rounded-2xl rounded-tr-sm bg-primary-700 px-3.5 py-2.5 text-sm text-white">
                        How is merit calculated?
                      </div>
                      <div className="max-w-[88%] rounded-2xl rounded-tl-sm bg-stone-100 px-3.5 py-2.5 text-sm text-stone-700">
                        Merit is generally 70% from Intermediate marks and 30%
                        from the entry test.
                      </div>
                    </div>
                    <div className="flex items-center gap-2 rounded-xl bg-stone-50 px-3 py-2.5 ring-1 ring-stone-200">
                      <span className="text-xs text-stone-400">Ask about fees, eligibility, deadlines…</span>
                      <span className="ml-auto flex h-7 w-7 items-center justify-center rounded-lg bg-primary-700 text-white">
                        <ChevronRight className="h-4 w-4" />
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </Reveal>
          </div>

          {/* Stats */}
          <Reveal delay={360}>
            <dl className="mt-16 grid grid-cols-3 gap-4 max-w-2xl">
              {heroStats.map((s) => (
                <div
                  key={s.label}
                  className="rounded-2xl bg-white/5 px-4 py-5 text-center ring-1 ring-white/10 backdrop-blur-sm"
                >
                  <dt className="text-xs uppercase tracking-wider text-primary-200">{s.label}</dt>
                  <dd className="mt-1.5 font-display text-3xl font-semibold text-white">{s.value}</dd>
                </div>
              ))}
            </dl>
          </Reveal>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-content mx-auto px-4 sm:px-6 lg:px-8 py-20 sm:py-24">
        <Reveal className="text-center max-w-2xl mx-auto">
          <p className="text-xs uppercase tracking-[0.18em] text-primary-700 font-semibold">
            Everything you need
          </p>
          <h2 className="mt-3 font-display text-3xl sm:text-4xl font-semibold text-stone-900 text-balance">
            One place for your entire UVAS admission journey
          </h2>
          <p className="mt-4 text-stone-600">
            From asking the AI a question to checking off your documents and
            tracking the timeline — it's all here.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {FEATURES.map((f, i) => (
            <Reveal key={f.to} delay={i * 70}>
              <Link
                to={f.to}
                className="group block h-full rounded-2xl border border-stone-200 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary-200 hover:shadow-xl hover:shadow-primary-900/5"
              >
                <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-700 transition-colors group-hover:bg-primary-700 group-hover:text-white">
                  <f.icon className="h-6 w-6" strokeWidth={2} />
                </span>
                <h3 className="mt-5 font-display text-lg font-semibold text-stone-900">
                  {f.title}
                </h3>
                <p className="mt-2 text-sm text-stone-600 leading-relaxed">{f.desc}</p>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-primary-700 opacity-0 transition-all group-hover:opacity-100">
                  Open
                  <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
                </span>
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* CTA banner */}
      <section className="max-w-content mx-auto px-4 sm:px-6 lg:px-8 pb-24">
        <Reveal>
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-primary-700 to-primary-900 px-8 py-14 sm:px-14 sm:py-16 text-white text-center">
            <div className="absolute -top-16 -right-10 h-64 w-64 rounded-full bg-accent-300/15 blur-3xl" />
            <div className="absolute -bottom-20 -left-10 h-64 w-64 rounded-full bg-primary-300/10 blur-3xl" />
            <div className="relative">
              <FileText className="h-9 w-9 mx-auto text-accent-300" />
              <h2 className="mt-5 font-display text-3xl sm:text-4xl font-semibold text-balance">
                Ready to get your questions answered?
              </h2>
              <p className="mt-4 max-w-xl mx-auto text-primary-100/90">
                The AI assistant only answers from official UVAS admission
                information — so you always get reliable, on-topic guidance.
              </p>
              <button
                onClick={() => navigate('/chat')}
                className="mt-8 inline-flex items-center gap-2 rounded-xl bg-white px-6 py-3.5 text-base font-semibold text-primary-800 shadow-lg transition-all hover:bg-accent-50 hover:shadow-xl active:scale-95"
              >
                <Bot className="h-5 w-5" />
                Start Asking
              </button>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}

import {
  CalendarCheck,
  ClipboardList,
  GraduationCap,
  IndianRupee,
  ListChecks,
  PenLine,
  type LucideIcon,
} from 'lucide-react';
import { timeline, type TimelineStep } from '@/data/content';
import { navigate } from '@/lib/router';
import { Reveal } from '@/components/Reveal';

const ICONS: Record<TimelineStep['icon'], LucideIcon> = {
  announce: CalendarCheck,
  apply: PenLine,
  test: ClipboardList,
  merit: ListChecks,
  fee: IndianRupee,
  enroll: GraduationCap,
};

export function TimelinePage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Reveal className="text-center">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-3.5 py-1.5 text-xs font-medium text-primary-700">
            <CalendarCheck className="h-3.5 w-3.5" />
            Admission Timeline
          </span>
          <h1 className="mt-5 font-display text-3xl sm:text-4xl font-semibold text-stone-900 text-balance">
            Your step-by-step path to UVAS
          </h1>
          <p className="mt-4 text-stone-600">
            From the admission announcement to your first day — here's what to
            expect and when.
          </p>
        </Reveal>

        <div className="mt-12 relative">
          {/* Vertical line */}
          <div className="absolute left-[27px] sm:left-[31px] top-2 bottom-2 w-0.5 bg-gradient-to-b from-primary-300 via-primary-500 to-primary-700" />

          <ol className="space-y-8">
            {timeline.map((s, i) => {
              const Icon = ICONS[s.icon];
              return (
                <Reveal key={s.step} delay={i * 90}>
                  <li className="relative flex gap-5 sm:gap-6">
                    {/* Node */}
                    <div className="relative z-10 flex shrink-0 flex-col items-center">
                      <span className="flex h-14 w-14 sm:h-16 sm:w-16 items-center justify-center rounded-2xl bg-white ring-4 ring-stone-50 shadow-md">
                        <span className="flex h-full w-full items-center justify-center rounded-2xl bg-gradient-to-br from-primary-600 to-primary-800 text-white">
                          <Icon className="h-6 w-6 sm:h-7 sm:w-7" strokeWidth={2} />
                        </span>
                      </span>
                    </div>

                    {/* Content */}
                    <div className="flex-1 rounded-2xl border border-stone-200 bg-white p-5 shadow-sm transition-all hover:shadow-md hover:border-primary-200 pb-6">
                      <div className="flex items-center gap-3">
                        <span className="inline-flex items-center rounded-full bg-primary-50 px-2.5 py-0.5 text-xs font-semibold text-primary-700">
                          Step {s.step}
                        </span>
                      </div>
                      <h3 className="mt-3 font-display text-lg font-semibold text-stone-900">
                        {s.title}
                      </h3>
                      <p className="mt-2 text-sm leading-relaxed text-stone-600">{s.description}</p>
                    </div>
                  </li>
                </Reveal>
              );
            })}
          </ol>
        </div>

        <Reveal delay={200}>
          <div className="mt-12 rounded-2xl bg-gradient-to-br from-primary-700 to-primary-900 px-6 py-8 text-center text-white">
            <h2 className="font-display text-xl font-semibold">Questions about any step?</h2>
            <p className="mt-2 text-sm text-primary-100/90">
              Ask the AI assistant for details on deadlines, fees, or requirements.
            </p>
            <button
              onClick={() => navigate('/chat')}
              className="mt-5 inline-flex items-center gap-2 rounded-xl bg-white px-5 py-3 text-sm font-semibold text-primary-800 transition-all hover:bg-accent-50 active:scale-95"
            >
              Ask the AI Assistant
            </button>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

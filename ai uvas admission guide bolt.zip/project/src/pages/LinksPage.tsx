import {
  ArrowUpRight,
  ExternalLink,
  Globe,
  HelpCircle,
  Link2,
  type LucideIcon,
} from 'lucide-react';
import { officialLinks, type OfficialLink } from '@/data/content';
import { navigate } from '@/lib/router';
import { Reveal } from '@/components/Reveal';

const ICONS: Record<OfficialLink['icon'], LucideIcon> = {
  globe: Globe,
  portal: Link2,
  mail: Link2,
  phone: Globe,
  map: Globe,
  help: HelpCircle,
};

export function LinksPage() {
  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <Reveal className="text-center max-w-2xl mx-auto">
          <span className="inline-flex items-center gap-2 rounded-full bg-primary-50 px-3.5 py-1.5 text-xs font-medium text-primary-700">
            <Link2 className="h-3.5 w-3.5" />
            Official Links
          </span>
          <h1 className="mt-5 font-display text-3xl sm:text-4xl font-semibold text-stone-900 text-balance">
            Official UVAS resources at your fingertips
          </h1>
          <p className="mt-4 text-stone-600">
            Use these official links to apply, verify information, or contact
            the university directly.
          </p>
        </Reveal>

        <div className="mt-12 grid gap-5 sm:grid-cols-2">
          {officialLinks.map((l, i) => {
            const Icon = ICONS[l.icon] ?? Globe;
            const isMail = l.url.startsWith('mailto:');
            const isExternal = !isMail;
            return (
              <Reveal key={l.label} delay={i * 70}>
                <a
                  href={l.url}
                  target={isExternal ? '_blank' : undefined}
                  rel={isExternal ? 'noopener noreferrer' : undefined}
                  className="group flex h-full flex-col rounded-2xl border border-stone-200 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-primary-200 hover:shadow-xl hover:shadow-primary-900/5"
                >
                  <div className="flex items-center justify-between">
                    <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary-50 text-primary-700 transition-colors group-hover:bg-primary-700 group-hover:text-white">
                      <Icon className="h-6 w-6" strokeWidth={2} />
                    </span>
                    <ArrowUpRight className="h-5 w-5 text-stone-300 transition-all group-hover:text-primary-600 group-hover:rotate-0" />
                  </div>
                  <h3 className="mt-5 font-display text-lg font-semibold text-stone-900">
                    {l.label}
                  </h3>
                  <p className="mt-2 text-sm leading-relaxed text-stone-600">{l.description}</p>
                  <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-medium text-primary-700">
                    {isMail ? 'Send email' : 'Open website'}
                    <ExternalLink className="h-3.5 w-3.5" />
                  </span>
                </a>
              </Reveal>
            );
          })}
        </div>

        <Reveal delay={200}>
          <div className="mt-12 rounded-2xl border border-amber-200 bg-amber-50 px-6 py-5">
            <p className="text-sm text-amber-900">
              <strong>Important:</strong> This guide is for informational
              purposes only and is not affiliated with UVAS. Always confirm
              deadlines, fees, and requirements on the official UVAS website or
              admissions portal.
            </p>
          </div>
        </Reveal>

        <Reveal delay={280}>
          <div className="mt-8 text-center">
            <p className="text-sm text-stone-600">Need an answer fast?</p>
            <button
              onClick={() => navigate('/chat')}
              className="mt-3 inline-flex items-center gap-2 rounded-xl bg-primary-700 px-5 py-3 text-sm font-semibold text-white transition-all hover:bg-primary-800 active:scale-95"
            >
              Ask the AI Assistant
            </button>
          </div>
        </Reveal>
      </div>
    </div>
  );
}

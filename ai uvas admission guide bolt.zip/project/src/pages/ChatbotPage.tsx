import { useEffect, useRef, useState } from 'react';
import {
  AlertCircle,
  Bot,
  ChevronRight,
  FileText,
  Send,
  ShieldCheck,
  Sparkles,
  User,
} from 'lucide-react';
import { answerQuery, loadAdmissionData, OFF_TOPIC_REPLY } from '@/lib/chatEngine';
import { navigate } from '@/lib/router';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  sources?: string[];
  status?: 'grounded' | 'missing' | 'offtopic';
}

const SUGGESTIONS = [
  'What is the duration of the DVM program?',
  'How is merit calculated?',
  'What documents are required for admission?',
  'Does UVAS offer scholarships?',
  'When do admissions usually open?',
  'What is the fee structure?',
];

const uid = () => Math.random().toString(36).slice(2, 10);

export function ChatbotPage() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: uid(),
      role: 'assistant',
      text:
        "Hello! I'm the UVAS Admission Guide assistant. I only answer from official UVAS admission information — no guessing. Ask me about programs, eligibility, fees, scholarships, the timeline, or required documents.",
      status: 'grounded',
    },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [dataReady, setDataReady] = useState(false);
  const [loadError, setLoadError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    loadAdmissionData()
      .then(() => setDataReady(true))
      .catch((e: unknown) => setLoadError(e instanceof Error ? e.message : 'Failed to load data'));
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, busy]);

  const send = async (text: string) => {
    const q = text.trim();
    if (!q || busy) return;
    if (!dataReady) {
      setLoadError('Admission data is still loading. Please try again in a moment.');
      return;
    }

    const userMsg: Message = { id: uid(), role: 'user', text: q };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setBusy(true);

    try {
      const data = await loadAdmissionData();
      const result = answerQuery(q, data);
      // Simulate brief "thinking" delay for natural feel.
      await new Promise((r) => setTimeout(r, 480));
      setMessages((m) => [
        ...m,
        {
          id: uid(),
          role: 'assistant',
          text: result.reply,
          sources: result.sources,
          status: result.grounded ? 'grounded' : result.reply === OFF_TOPIC_REPLY ? 'offtopic' : 'missing',
        },
      ]);
    } catch {
      setMessages((m) => [
        ...m,
        {
          id: uid(),
          role: 'assistant',
          text: 'Something went wrong while reading the admission data. Please try again.',
          status: 'missing',
        },
      ]);
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    send(input);
  };

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-stone-50 pt-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center gap-4">
          <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-primary-700 text-white shadow-sm">
            <Bot className="h-6 w-6" />
          </span>
          <div>
            <h1 className="font-display text-2xl sm:text-3xl font-semibold text-stone-900">
              UVAS Admission Assistant
            </h1>
            <p className="mt-0.5 text-sm text-stone-500 flex items-center gap-2">
              <span className="relative flex h-2 w-2">
                {dataReady && <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-500 opacity-75" />}
                <span className={`relative inline-flex h-2 w-2 rounded-full ${dataReady ? 'bg-green-500' : 'bg-amber-400'}`} />
              </span>
              {dataReady ? 'Online · grounded in official admission data' : 'Loading admission data…'}
            </p>
          </div>
        </div>

        {/* Trust banner */}
        <div className="mt-5 flex flex-wrap gap-2.5">
          {[
            { icon: ShieldCheck, text: 'Only uses official UVAS data' },
            { icon: AlertCircle, text: 'Refuses to guess' },
            { icon: Sparkles, text: 'Stays on-topic' },
          ].map((t) => (
            <span
              key={t.text}
              className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-xs font-medium text-stone-600 ring-1 ring-stone-200"
            >
              <t.icon className="h-3.5 w-3.5 text-primary-700" />
              {t.text}
            </span>
          ))}
        </div>

        {/* Chat window */}
        <div className="mt-6 flex flex-col rounded-3xl border border-stone-200 bg-white shadow-sm overflow-hidden">
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto scrollbar-thin px-4 sm:px-6 py-6 space-y-5"
            style={{ minHeight: '420px', maxHeight: '58vh' }}
          >
            {messages.map((m) => (
              <MessageBubble key={m.id} message={m} />
            ))}
            {busy && <TypingIndicator />}
            {loadError && (
              <div className="rounded-xl bg-amber-50 px-4 py-3 text-sm text-amber-800 ring-1 ring-amber-200">
                {loadError}
              </div>
            )}
          </div>

          {/* Suggestions */}
          {messages.length <= 1 && (
            <div className="border-t border-stone-100 px-4 sm:px-6 py-4 bg-stone-50/60">
              <p className="text-xs font-medium text-stone-500 mb-2.5">Try one of these:</p>
              <div className="flex flex-wrap gap-2">
                {SUGGESTIONS.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    disabled={busy || !dataReady}
                    className="group inline-flex items-center gap-1.5 rounded-full bg-white px-3.5 py-1.5 text-sm text-stone-700 ring-1 ring-stone-200 transition-all hover:ring-primary-300 hover:text-primary-800 disabled:opacity-50"
                  >
                    {s}
                    <ChevronRight className="h-3.5 w-3.5 opacity-0 transition-all group-hover:opacity-100" />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Composer */}
          <form onSubmit={onSubmit} className="border-t border-stone-100 p-3 sm:p-4 bg-white">
            <div className="flex items-end gap-2 rounded-2xl bg-stone-50 px-3 py-2 ring-1 ring-stone-200 focus-within:ring-2 focus-within:ring-primary-500 transition">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    send(input);
                  }
                }}
                rows={1}
                placeholder="Ask about UVAS admissions…"
                className="flex-1 resize-none bg-transparent text-sm text-stone-800 placeholder:text-stone-400 focus:outline-none max-h-32 py-1.5"
                disabled={busy}
              />
              <button
                type="submit"
                disabled={busy || !input.trim() || !dataReady}
                className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary-700 text-white transition-all hover:bg-primary-800 active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
                aria-label="Send message"
              >
                <Send className="h-4 w-4" />
              </button>
            </div>
            <p className="mt-2 px-1 text-[11px] text-stone-400">
              The assistant only answers from official UVAS admission information. Press Enter to send.
            </p>
          </form>
        </div>

        <p className="mt-5 text-center text-xs text-stone-400">
          Need more help?{' '}
          <button onClick={() => navigate('/links')} className="text-primary-700 hover:underline font-medium">
            Visit official UVAS links
          </button>
        </p>
      </div>
    </div>
  );
}

function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === 'user';
  return (
    <div className={`flex gap-3 animate-fadeInUp ${isUser ? 'flex-row-reverse' : ''}`}>
      <span
        className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
          isUser ? 'bg-stone-200 text-stone-600' : 'bg-primary-700 text-white'
        }`}
      >
        {isUser ? <User className="h-5 w-5" /> : <Bot className="h-5 w-5" />}
      </span>
      <div className={`max-w-[82%] ${isUser ? 'items-end' : 'items-start'} flex flex-col`}>
        <div
          className={`rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${
            isUser
              ? 'bg-primary-700 text-white rounded-tr-sm'
              : message.status === 'offtopic'
              ? 'bg-amber-50 text-amber-900 ring-1 ring-amber-200 rounded-tl-sm'
              : message.status === 'missing'
              ? 'bg-stone-100 text-stone-600 rounded-tl-sm'
              : 'bg-stone-100 text-stone-800 rounded-tl-sm'
          }`}
        >
          {message.text}
        </div>

        {message.sources && message.sources.length > 0 && (
          <div className="mt-2 flex items-center gap-1.5 flex-wrap">
            <FileText className="h-3.5 w-3.5 text-primary-600" />
            <span className="text-[11px] font-medium text-stone-500">Source:</span>
            {message.sources.map((s, i) => (
              <span
                key={i}
                className="inline-flex items-center rounded-md bg-primary-50 px-2 py-0.5 text-[11px] font-medium text-primary-700"
              >
                {s}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function TypingIndicator() {
  return (
    <div className="flex gap-3 animate-fadeIn">
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-primary-700 text-white">
        <Bot className="h-5 w-5" />
      </span>
      <div className="rounded-2xl rounded-tl-sm bg-stone-100 px-4 py-3.5">
        <div className="flex items-center gap-1.5">
          <span className="h-2 w-2 rounded-full bg-stone-400 animate-blink" style={{ animationDelay: '0s' }} />
          <span className="h-2 w-2 rounded-full bg-stone-400 animate-blink" style={{ animationDelay: '0.2s' }} />
          <span className="h-2 w-2 rounded-full bg-stone-400 animate-blink" style={{ animationDelay: '0.4s' }} />
        </div>
      </div>
    </div>
  );
}
